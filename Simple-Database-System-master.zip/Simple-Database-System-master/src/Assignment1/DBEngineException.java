package Assignment1;

public class DBEngineException extends RuntimeException{
	
public DBEngineException(){
	super();
}
public DBEngineException(String m){
	super(m);
}
}
