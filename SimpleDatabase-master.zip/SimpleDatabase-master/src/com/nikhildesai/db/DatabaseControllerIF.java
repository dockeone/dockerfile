package com.nikhildesai.db;

public interface DatabaseControllerIF {

    void executeCommand(String inputLine);

}