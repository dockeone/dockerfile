database
=========

#####A simple SQL database implemented with Java.
######To run this game, first run the following to compile:
```bash
make clean
make
```
######then you can use the following java command to run the game:
```bash
java db61b.Main
```   
######This database supports the following SQL functions:
- creat
- load
- store
- insert
- print
- select with condition

######*For detailed specification, please read Specification.pdf, written by Professor Hilfinger.*######

<sub>*Note: This is a CS 61B course project of University of California, Berkeley* </sub>
